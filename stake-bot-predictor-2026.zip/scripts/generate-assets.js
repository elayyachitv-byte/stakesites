import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPNG(width, height, getPixel) {
  const rowSize = width * 4 + 1;
  const raw = Buffer.alloc(height * rowSize);
  for (let y = 0; y < height; y++) {
    raw[y * rowSize] = 0;
    for (let x = 0; x < width; x++) {
      const idx = y * rowSize + 1 + x * 4;
      const [r, g, b, a] = getPixel(x, y, width, height);
      raw[idx] = r;
      raw[idx + 1] = g;
      raw[idx + 2] = b;
      raw[idx + 3] = a;
    }
  }
  const compressed = zlib.deflateSync(raw);

  function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const t = Buffer.from(type);
    const body = Buffer.concat([t, data]);
    const crc = crc32(body);
    const c = Buffer.alloc(4);
    c.writeUInt32BE(crc, 0);
    return Buffer.concat([len, t, data, c]);
  }

  function crc32(buf) {
    let c = ~0;
    for (let i = 0; i < buf.length; i++) {
      c ^= buf[i];
      for (let j = 0; j < 8; j++) {
        c = (c >>> 1) ^ (0xEDB88320 & -(c & 1));
      }
    }
    return ~c >>> 0;
  }

  const header = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  return Buffer.concat([header, chunk('IHDR', ihdr), chunk('IDAT', compressed), chunk('IEND', Buffer.alloc(0))]);
}

const publicDir = path.resolve('public');
fs.mkdirSync(publicDir, { recursive: true });

// 1. favicon-16x16.png: Neon diamond
fs.writeFileSync(path.join(publicDir, 'favicon-16x16.png'), createPNG(16, 16, (x, y) => {
  const dx = Math.abs(x - 7.5);
  const dy = Math.abs(y - 7.5);
  // Diamond shape
  if (dx + dy <= 6.5) {
    // S letter in center
    if ((y === 5 && x >= 6 && x <= 9) ||
        (y === 6 && x === 6) ||
        (y === 7 && x >= 6 && x <= 9) ||
        (y === 8 && x === 9) ||
        (y === 9 && x >= 6 && x <= 9)) {
      return [0, 0, 0, 255];
    }
    return [0, 255, 170, 255];
  }
  return [0, 0, 0, 0];
}));

// 2. favicon-32x32.png
fs.writeFileSync(path.join(publicDir, 'favicon-32x32.png'), createPNG(32, 32, (x, y) => {
  const dx = Math.abs(x - 15.5);
  const dy = Math.abs(y - 15.5);
  if (dx + dy <= 13.5) {
    // Inner border
    if (dx + dy <= 10.5 && dx + dy >= 9.0) {
      return [0, 210, 140, 255];
    }
    // S letter
    if (x >= 12 && x <= 19 && y >= 10 && y <= 21) {
      const cy = y - 10;
      const cx = x - 12;
      const isS = (cy <= 2) || (cy >= 4 && cy <= 6) || (cy >= 9) ||
                  (cx <= 2 && cy < 6) || (cx >= 5 && cy > 4);
      if (isS) return [10, 15, 25, 255];
    }
    return [0, 255, 170, 255];
  }
  return [0, 0, 0, 0];
}));

// 3. apple-touch-icon.png (180x180)
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPNG(180, 180, (x, y) => {
  const dx = Math.abs(x - 89.5);
  const dy = Math.abs(y - 89.5);
  
  // Background subtle gradient
  const bgR = Math.round(238 - (y / 180) * 15);
  const bgG = Math.round(240 - (y / 180) * 15);
  const bgB = Math.round(248 - (y / 180) * 10);
  
  // Diamond outer
  if (dx + dy <= 72) {
    // Double layered emerald diamond
    if (dx + dy <= 52 && dx + dy >= 36) {
      return [0, 204, 136, 255];
    }
    // S letter in center
    if (dx + dy <= 34) {
      const lx = x - 90;
      const ly = y - 90;
      // Bold S shape
      if (lx >= -14 && lx <= 14 && ly >= -22 && ly <= 22) {
        const topBar = (ly >= -22 && ly <= -14);
        const midBar = (ly >= -4 && ly <= 4);
        const botBar = (ly >= 14 && ly <= 22);
        const leftArm = (lx <= -6 && ly < 0);
        const rightArm = (lx >= 6 && ly > 0);
        if (topBar || midBar || botBar || leftArm || rightArm) {
          return [5, 10, 20, 255];
        }
      }
    }
    return [0, 255, 170, 255];
  }
  
  return [bgR, bgG, bgB, 255];
}));

// 4. og-image.png (1200x630) and twitter-image.png
const ogImage = createPNG(1200, 630, (x, y) => {
  // Dark cyber background with subtle glow
  let r = 11, g = 12, b = 22;
  
  // Emerald circle on the left
  const circleX = 260;
  const circleY = 315;
  const distCircle = Math.sqrt((x - circleX)**2 + (y - circleY)**2);
  
  if (distCircle < 210) {
    // Green circular badge
    r = 13; g = 71; b = 52;
    // Diamond icon inside circle
    const ddx = Math.abs(x - circleX);
    const ddy = Math.abs(y - circleY);
    if (ddx + ddy <= 110 && ddx + ddy >= 80) {
      return [0, 255, 170, 255]; // neon green stroke
    }
    if (ddx + ddy < 80) {
      return [0, 220, 145, 255]; // fill
    }
    return [r, g, b, 255];
  }
  
  // Radial glow around badge
  if (distCircle < 340) {
    const factor = (340 - distCircle) / 130;
    g = Math.min(255, g + Math.round(40 * factor));
    b = Math.min(255, b + Math.round(25 * factor));
  }
  
  // Accent gradient line at top
  if (y < 6) return [0, 255, 170, 255];
  
  return [r, g, b, 255];
});

fs.writeFileSync(path.join(publicDir, 'og-image.png'), ogImage);
fs.writeFileSync(path.join(publicDir, 'twitter-image.png'), ogImage);

console.log('All image assets created successfully in /public');
