#!/usr/bin/env python3
"""
Packaging script for Stake Bot Predictor WordPress Plugin.
Compiles frontend, organizes directories, and generates stake-bot-predictor.zip.
"""

import os
import shutil
import subprocess
import zipfile
import re

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PLUGIN_DIR = os.path.join(ROOT_DIR, 'stake-bot-predictor')
DIST_DIR = os.path.join(ROOT_DIR, 'dist')
ZIP_OUTPUT = os.path.join(ROOT_DIR, 'stake-bot-predictor.zip')
PUBLIC_ZIP = os.path.join(ROOT_DIR, 'public', 'stake-bot-predictor.zip')

print("1. Running Vite build...")
subprocess.run(['npm', 'run', 'build'], cwd=ROOT_DIR, check=True)

print("2. Ensuring destination directories in plugin...")
plugin_public_js = os.path.join(PLUGIN_DIR, 'public', 'js')
plugin_public_css = os.path.join(PLUGIN_DIR, 'public', 'css')
plugin_public_assets = os.path.join(PLUGIN_DIR, 'public', 'assets')
plugin_repo_assets = os.path.join(PLUGIN_DIR, 'assets')

os.makedirs(plugin_public_js, exist_ok=True)
os.makedirs(plugin_public_css, exist_ok=True)
os.makedirs(plugin_public_assets, exist_ok=True)
os.makedirs(plugin_repo_assets, exist_ok=True)

# Find compiled JS and CSS in dist/assets
dist_assets = os.path.join(DIST_DIR, 'assets')
found_js = None
found_css = None

for file in os.listdir(dist_assets):
    if file.endswith('.js') and file.startswith('index-'):
        found_js = os.path.join(dist_assets, file)
    elif file.endswith('.css') and file.startswith('index-'):
        found_css = os.path.join(dist_assets, file)

if not found_js or not found_css:
    raise RuntimeError(f"Could not find compiled assets in {dist_assets}")

print(f"-> Copying JS: {found_js} -> {os.path.join(plugin_public_js, 'app.js')}")
shutil.copyfile(found_js, os.path.join(plugin_public_js, 'app.js'))

print(f"-> Copying CSS: {found_css} -> {os.path.join(plugin_public_css, 'app.css')}")
shutil.copyfile(found_css, os.path.join(plugin_public_css, 'app.css'))

# Copy public images to plugin public/assets
public_dir = os.path.join(ROOT_DIR, 'public')
if os.path.exists(public_dir):
    for item in os.listdir(public_dir):
        if item.endswith(('.png', '.svg', '.ico', '.jpg', '.jpeg', '.webmanifest')):
            src = os.path.join(public_dir, item)
            shutil.copyfile(src, os.path.join(plugin_public_assets, item))
            # Also copy icon and banner for WP repo assets if appropriate
            if 'favicon-32x32' in item:
                shutil.copyfile(src, os.path.join(plugin_repo_assets, 'icon-128x128.png'))
            elif 'apple-touch-icon' in item:
                shutil.copyfile(src, os.path.join(plugin_repo_assets, 'icon-256x256.png'))
            elif 'og-image' in item:
                shutil.copyfile(src, os.path.join(plugin_repo_assets, 'banner-772x250.png'))

print("3. Building stake-bot-predictor.zip...")
if os.path.exists(ZIP_OUTPUT):
    os.remove(ZIP_OUTPUT)

with zipfile.ZipFile(ZIP_OUTPUT, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(PLUGIN_DIR):
        for file in files:
            file_path = os.path.join(root, file)
            # Relative path starting with 'stake-bot-predictor/...'
            rel_path = os.path.relpath(file_path, ROOT_DIR)
            zipf.write(file_path, rel_path)

print(f"✓ Created {ZIP_OUTPUT} ({os.path.getsize(ZIP_OUTPUT)} bytes)")

# Also copy to public directory for easy frontend download if needed
shutil.copyfile(ZIP_OUTPUT, PUBLIC_ZIP)
print(f"✓ Copied to {PUBLIC_ZIP}")

# Verify zip file structure
with zipfile.ZipFile(ZIP_OUTPUT, 'r') as z:
    names = z.namelist()
    has_main_file = 'stake-bot-predictor/stake-bot-predictor.php' in names
    has_app_js = 'stake-bot-predictor/public/js/app.js' in names
    has_app_css = 'stake-bot-predictor/public/css/app.css' in names
    print(f"Validation: has_main_file={has_main_file}, has_app_js={has_app_js}, has_app_css={has_app_css}")
    if not (has_main_file and has_app_js and has_app_css):
        raise RuntimeError("ZIP validation failed! Required files are missing.")

print("\nSUCCESS: WordPress Plugin successfully packaged into stake-bot-predictor.zip!")
