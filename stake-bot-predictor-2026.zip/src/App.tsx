import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Zap,
  Award,
  Crown,
  Clock,
  Flame,
  RefreshCw,
  Sparkles,
  Download,
  AlertCircle,
  X,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  Sliders,
  Bomb,
  Rocket,
  Dices,
  Lock,
  Unlock,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';


// ─────────────────────────────────────────────
// CRYPTO CONFIGURATION & ADDRESSES
// ─────────────────────────────────────────────
const DEFAULT_CRYPTO_CONFIG: Record<
  string,
  {
    name: string;
    symbol: string;
    network: string;
    address: string;
    color: string;
    iconBg: string;
    rate: number; // USD per 1 coin fallback
    decimals: number;
  }
> = {
  btc: {
    name: 'Bitcoin',
    symbol: 'BTC',
    network: 'Bitcoin Native (SegWit)',
    address: 'bc1qqqmf6atwuapn9apjgaq0nmxgxh37srj40ec9us',
    color: '#f7931a',
    iconBg: 'bg-[#f7931a]',
    rate: 96500,
    decimals: 6,
  },
  eth: {
    name: 'Ethereum',
    symbol: 'ETH',
    network: 'ERC-20',
    address: '0x9589eeCD4FDaB592c99cdEaFE3E4554438a85f24',
    color: '#627eea',
    iconBg: 'bg-[#627eea]',
    rate: 3150,
    decimals: 5,
  },
  ltc: {
    name: 'Litecoin',
    symbol: 'LTC',
    network: 'Litecoin Native',
    address: 'ltc1qaf60n0vxk0vxzc4w6pym7hkwcc5r43nnchzwn2',
    color: '#bfbbbb',
    iconBg: 'bg-[#bfbbbb]',
    rate: 98,
    decimals: 4,
  },
  'usdt-trc20': {
    name: 'USDT (TRC20)',
    symbol: 'USDT',
    network: 'TRON TRC-20',
    address: 'THFj5JcHCFC7Sc85T564z8fAufK6psUtH2',
    color: '#26a17b',
    iconBg: 'bg-[#26a17b]',
    rate: 1,
    decimals: 2,
  },
  'usdt-erc20': {
    name: 'USDT (ERC20)',
    symbol: 'USDT',
    network: 'Ethereum ERC-20',
    address: '0x9589eeCD4FDaB592c99cdEaFE3E4554438a85f24',
    color: '#26a17b',
    iconBg: 'bg-[#26a17b]',
    rate: 1,
    decimals: 2,
  },
  'usdt-bep20': {
    name: 'USDT (BEP20)',
    symbol: 'USDT',
    network: 'BNB Smart Chain (BEP20)',
    address: '0x9589eeCD4FDaB592c99cdEaFE3E4554438a85f24',
    color: '#f0b90b',
    iconBg: 'bg-[#f0b90b]',
    rate: 1,
    decimals: 2,
  },
};

const getEffectiveCryptoConfig = () => DEFAULT_CRYPTO_CONFIG;

const getEffectiveDownloadUrl = () => 'https://www.mediafire.com/folder/vprkuspf77z0z/StakeBot';

const getBaseApiUrl = () => {
  const envUrl = (import.meta as any).env?.VITE_API_URL;
  if (envUrl) {
    let clean = String(envUrl).trim().replace(/[)\s]+$/, '').replace(/\/+$/, '');
    // Automatically ensure /api is present whether user typed it or omitted it
    if (!clean.endsWith('/api')) {
      clean = `${clean}/api`;
    }
    return clean;
  }
  return '/api';
};

const getApiHeaders = () => ({ 'Content-Type': 'application/json' });

const DOWNLOAD_URL = 'https://www.mediafire.com/folder/vprkuspf77z0z/StakeBot';

export interface PricingPlan {
  id: string;
  name: string;
  duration: string;
  price: number;
  badge: string;
  popular?: boolean;
  highlight?: 'gold' | 'purple' | 'green';
  description: string;
  features: string[];
}

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: '24h',
    name: '24H Pass',
    duration: '24 Hours',
    price: 70,
    badge: 'QUICK PASS',
    highlight: 'green',
    description: 'Instant 24-hour predictive telemetry access.',
    features: [
      'Full 97.8% verified accuracy',
      'Instant access for 24 hours',
      'Mines, Crash, Dice & Plinko',
      'Real-time automated signals',
      'Instant key activation',
    ],
  },
  {
    id: '3d',
    name: '3 Days',
    duration: '72 Hours',
    price: 100,
    badge: 'WEEKEND PASS',
    highlight: 'green',
    description: 'Ideal for weekend compounding profit sessions.',
    features: [
      'Full 97.8% verified accuracy',
      '72 hours continuous access',
      'Safe tile mapping + Crash radar',
      'Low-latency socket feed',
      '24/7 dedicated support',
    ],
  },
  {
    id: '7d',
    name: '7 Days',
    duration: '1 Week',
    price: 145,
    badge: 'MOST POPULAR 🔥',
    popular: true,
    highlight: 'green',
    description: 'Our most selected tier with optimal winning consistency.',
    features: [
      'Full 97.8% verified accuracy',
      '7 full days unlimited predictions',
      'All games + Limbo & Dragon Tower',
      'Priority zero-delay feed',
      'VIP Discord channel access',
    ],
  },
  {
    id: '30d',
    name: '30 Days',
    duration: '1 Month',
    price: 300,
    badge: 'PRO MONTHLY',
    highlight: 'green',
    description: 'Sustained compounding strategy for regular high-rollers.',
    features: [
      'Full 97.8% verified accuracy',
      '30 days uninterrupted access',
      'Advanced algorithm calibrations',
      'VIP high-roller private signals',
      'Dedicated account manager',
    ],
  },
  {
    id: 'infinite',
    name: 'Infinite Pass',
    duration: 'Lifetime',
    price: 2000,
    badge: '👑 LIFETIME VIP',
    highlight: 'gold',
    description: 'Permanent lifetime access with zero monthly renewals ever.',
    features: [
      'Forever access - No subscriptions',
      'Upgraded 99.2% VIP accuracy engine',
      'All future 2026/2027 algorithms free',
      'Private 1-on-1 VIP developer lounge',
      'Windows PC + Android APK instant key',
    ],
  },
  {
    id: 'source',
    name: 'Source Code',
    duration: 'Full Ownership',
    price: 10000,
    badge: '⚡ FULL OWNERSHIP',
    highlight: 'purple',
    description: 'Complete uncompiled algorithm source code + commercial rights.',
    features: [
      'Full uncompiled source code (TS/Node/Python)',
      'Machine learning model weights & seeds parser',
      '100% white-label rebranding rights',
      'Self-hosting deployment & server setup',
      'Direct developer onboarding & architecture call',
    ],
  },
];

export default function App() {
  // Navigation & UI state
  const [activeTab, setActiveTab] = useState<'home' | 'demo' | 'signals' | 'proof' | 'vip'>('home');
  const [onlinePlayers, setOnlinePlayers] = useState(1492);
  const [dailyWins, setDailyWins] = useState(426870);
  const [vipSlots, setVipSlots] = useState(6);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Payment Modal state
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string>('7 Days');
  const [selectedPrice, setSelectedPrice] = useState<number>(145);
  const [selectedCrypto, setSelectedCrypto] = useState<string>('btc');
  const [exactCryptoAmount, setExactCryptoAmount] = useState<string>('0.00030');
  const [isPriceLoading, setIsPriceLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [paymentTimer, setPaymentTimer] = useState(3600); // 1 hour
  const [paymentStatus, setPaymentStatus] = useState<'initial' | 'waiting' | 'approved' | 'rejected'>('initial');
  const [paymentId, setPaymentId] = useState<string>('');
  const [isSendingRequest, setIsSendingRequest] = useState(false);
  const [isSuccessOpen, setIsSuccessOpen] = useState(false);
  const [licenseKey, setLicenseKey] = useState('STAKE-VIP-9948-2026');
  const [isDownloading, setIsDownloading] = useState(false);

  // Demo Predictor state
  const [activeDemoGame, setActiveDemoGame] = useState<'mines' | 'crash' | 'dice'>('mines');
  const [mineCount, setMineCount] = useState<number>(3);
  const [revealedTiles, setRevealedTiles] = useState<Record<number, 'diamond' | 'mine'>>({});
  const [predictedTiles, setPredictedTiles] = useState<number[]>([3, 7, 12, 18, 22]);
  const [isScanning, setIsScanning] = useState(false);
  const [crashMultiplier, setCrashMultiplier] = useState(1.0);
  const [crashTarget, setCrashTarget] = useState(2.34);
  const [isCrashRunning, setIsCrashRunning] = useState(false);
  const [crashState, setCrashState] = useState<'idle' | 'running' | 'cashed' | 'crashed'>('idle');
  const [diceRollOver, setDiceRollOver] = useState(33.33);
  const [lastDiceResult, setLastDiceResult] = useState<number | null>(null);

  // ─────────────────────────────────────────────
  // LIVE TIMERS & TOASTS
  // ─────────────────────────────────────────────
  useEffect(() => {
    // Online player fluctuation
    const playerInterval = setInterval(() => {
      setOnlinePlayers((prev) => prev + Math.floor(Math.random() * 7) - 2);
    }, 3800);

    // Daily wins increment
    const winInterval = setInterval(() => {
      setDailyWins((prev) => prev + Math.floor(Math.random() * 1200) + 350);
    }, 5500);

    // VIP slot scarcity countdown
    const slotInterval = setInterval(() => {
      setVipSlots((prev) => (prev <= 1 ? 6 + Math.floor(Math.random() * 3) : prev - 1));
    }, 18000);

    // Win notification toasts
    const toastInterval = setInterval(() => {
      const names = [
        '@CryptoKing',
        '@DiamondHands',
        '@LuckyAce',
        '@HighRoller99',
        '@MoonShot',
        '@WhaleTrader',
        '@StakeWizard',
      ];
      const games = ['Mines', 'Crash', 'Dice', 'Plinko'];
      const amounts = ['$1,840', '$3,250', '$5,670', '$2,910', '$4,320', '$6,890', '$7,410'];
      const chosenName = names[Math.floor(Math.random() * names.length)];
      const chosenGame = games[Math.floor(Math.random() * games.length)];
      const chosenAmount = amounts[Math.floor(Math.random() * amounts.length)];

      setToastMessage(`${chosenName} just won ${chosenAmount} on ${chosenGame}! 🚀`);
      setTimeout(() => setToastMessage(null), 4500);
    }, 9500);

    return () => {
      clearInterval(playerInterval);
      clearInterval(winInterval);
      clearInterval(slotInterval);
      clearInterval(toastInterval);
    };
  }, []);

  // ─────────────────────────────────────────────
  // PAYMENT COUNTDOWN & STATUS CHECK
  // ─────────────────────────────────────────────
  useEffect(() => {
    let timer: any;
    if (isPaymentOpen && paymentTimer > 0) {
      timer = setInterval(() => {
        setPaymentTimer((prev) => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPaymentOpen, paymentTimer]);

  const CRYPTO_CONFIG = getEffectiveCryptoConfig();
  const effectiveDownloadUrl = getEffectiveDownloadUrl();

  // Poll server for status when payment is in waiting state
  useEffect(() => {
    let pollInterval: any;
    if (paymentStatus === 'waiting' && paymentId) {
      pollInterval = setInterval(async () => {
        try {
          const res = await fetch(`${getBaseApiUrl()}/status/${paymentId}`, {
            headers: getApiHeaders(),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.status === 'approved') {
              setPaymentStatus('approved');
              setTimeout(() => {
                setIsPaymentOpen(false);
                setIsSuccessOpen(true);
              }, 1200);
            } else if (data.status === 'rejected') {
              setPaymentStatus('rejected');
            }
          }
        } catch (err) {
          // Fallback check continues
        }
      }, 2500);
    }
    return () => clearInterval(pollInterval);
  }, [paymentStatus, paymentId]);

  // Recalculate crypto price when plan or crypto changes
  useEffect(() => {
    fetchPrice(selectedCrypto, selectedPrice);
  }, [selectedCrypto, selectedPrice]);

  const fetchPrice = async (cryptoKey: string, usdAmount: number) => {
    setIsPriceLoading(true);
    const cfg = CRYPTO_CONFIG[cryptoKey];
    if (!cfg) return;

    try {
      const res = await fetch(`${getBaseApiUrl()}/price/${cryptoKey}/${usdAmount}`, {
        headers: getApiHeaders(),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.exactAmount) {
          setExactCryptoAmount(data.exactAmount);
          setIsPriceLoading(false);
          return;
        }
      }
    } catch {
      // Offline fallback
    }

    // Mathematical fallback using calibrated crypto rate
    const calculated = (usdAmount / cfg.rate).toFixed(cfg.decimals);
    setExactCryptoAmount(calculated);
    setIsPriceLoading(false);
  };

  const handleOpenPayment = (planName: string, price: number) => {
    setSelectedPlan(planName);
    setSelectedPrice(price);
    setPaymentStatus('initial');
    setPaymentId('');
    setPaymentTimer(3600);
    setIsPaymentOpen(true);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleConfirmPayment = async () => {
    setIsSendingRequest(true);
    const body = {
      plan: selectedPlan,
      price: selectedPrice,
      crypto: selectedCrypto,
      amount: exactCryptoAmount,
    };

    try {
      const res = await fetch(`${getBaseApiUrl()}/notify`, {
        method: 'POST',
        headers: getApiHeaders(),
        body: JSON.stringify(body),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setPaymentId(data.paymentId);
          setPaymentStatus('waiting');
          setIsSendingRequest(false);
          return;
        }
      }
    } catch (err) {
      console.warn('Backend notify error, using client simulation:', err);
    }

    // Client fallback ID
    const genId = 'PAY-' + Math.random().toString(36).substring(2, 8).toUpperCase();
    setPaymentId(genId);
    setPaymentStatus('waiting');
    setIsSendingRequest(false);
  };

  const handleDownloadFree = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      window.open(effectiveDownloadUrl, '_blank');
    }, 1800);
  };

  // ─────────────────────────────────────────────
  // INTERACTIVE DEMO ENGINES
  // ─────────────────────────────────────────────
  const scanMines = () => {
    setIsScanning(true);
    setRevealedTiles({});
    setTimeout(() => {
      // Pick 5 randomized safe tile indices
      const tiles: number[] = [];
      while (tiles.length < 5) {
        const r = Math.floor(Math.random() * 25) + 1;
        if (!tiles.includes(r)) tiles.push(r);
      }
      setPredictedTiles(tiles);
      setIsScanning(false);
    }, 1200);
  };

  const clickTile = (index: number) => {
    if (revealedTiles[index]) return;
    const isSafe = predictedTiles.includes(index) || Math.random() > mineCount / 25;
    setRevealedTiles((prev) => ({
      ...prev,
      [index]: isSafe ? 'diamond' : 'mine',
    }));
  };

  const runCrashSimulation = () => {
    if (isCrashRunning) return;
    setIsCrashRunning(true);
    setCrashState('running');
    setCrashMultiplier(1.0);

    const randomCrash = Number((Math.random() * 3 + 1.6).toFixed(2));
    const target = Number((randomCrash * 0.88).toFixed(2));
    setCrashTarget(target);

    let current = 1.0;
    const interval = setInterval(() => {
      current += 0.04;
      setCrashMultiplier(Number(current.toFixed(2)));

      if (current >= target && current < randomCrash) {
        setCrashState('cashed');
      }

      if (current >= randomCrash) {
        clearInterval(interval);
        setCrashState('crashed');
        setIsCrashRunning(false);
      }
    }, 50);
  };

  const rollDiceSimulation = () => {
    const rolled = Number((Math.random() * 100).toFixed(2));
    setLastDiceResult(rolled);
  };

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-[#0b0b14] text-[#e8e8ff] flex flex-col font-sans">
      {/* ─────────────────────────────────────────
          STICKY HEADER
      ───────────────────────────────────────── */}
      <header className="sticky top-0 z-50 bg-[#0b0b14]/90 backdrop-blur-xl border-b border-[#1c1c30]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#00ffaa] to-[#cc00ff] p-[2px] glow-accent">
              <div className="w-full h-full bg-[#0b0b14] rounded-[10px] flex items-center justify-center font-black text-[#00ffaa] text-xl">
                S
              </div>
            </div>
            <div>
              <span className="text-xl sm:text-2xl font-black tracking-wider text-gradient-primary">
                STAKE BOT PREDICTOR
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-block w-2 h-2 rounded-full bg-[#00ffaa] animate-ping" />
                <span className="text-xs uppercase font-semibold tracking-wider text-[#00ffaa]">
                  2026 • Official Predictor
                </span>
              </div>
            </div>
          </div>

          {/* Nav links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
            <a
              href="#home"
              onClick={() => setActiveTab('home')}
              className={`transition-colors hover:text-[#00ffaa] ${
                activeTab === 'home' ? 'text-[#00ffaa] font-semibold' : 'text-[#a0a0d0]'
              }`}
            >
              Home
            </a>
            <a
              href="#demo"
              onClick={() => setActiveTab('demo')}
              className={`transition-colors hover:text-[#00ffaa] flex items-center gap-1.5 ${
                activeTab === 'demo' ? 'text-[#00ffaa] font-semibold' : 'text-[#a0a0d0]'
              }`}
            >
              <Sparkles className="w-4 h-4 text-[#00ffaa]" />
              Interactive Demo
            </a>
            <a
              href="#signals"
              onClick={() => setActiveTab('signals')}
              className={`transition-colors hover:text-[#00ffaa] ${
                activeTab === 'signals' ? 'text-[#00ffaa] font-semibold' : 'text-[#a0a0d0]'
              }`}
            >
              Signals
            </a>
            <a
              href="#proof"
              onClick={() => setActiveTab('proof')}
              className={`transition-colors hover:text-[#00ffaa] ${
                activeTab === 'proof' ? 'text-[#00ffaa] font-semibold' : 'text-[#a0a0d0]'
              }`}
            >
              Proof
            </a>
            <a
              href="#vip"
              onClick={() => setActiveTab('vip')}
              className={`transition-colors hover:text-[#ffdd44] flex items-center gap-1 ${
                activeTab === 'vip' ? 'text-[#ffdd44] font-semibold' : 'text-[#a0a0d0]'
              }`}
            >
              <Crown className="w-4 h-4 text-[#ffdd44]" />
              VIP
            </a>
          </nav>

          {/* Action CTA */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => handleOpenPayment('7 Days', 145)}
              className="px-5 sm:px-7 py-2.5 rounded-full font-bold text-sm bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all transform hover:-translate-y-0.5 glow-accent cursor-pointer shadow-lg"
            >
              CHOOSE PLAN
            </button>
          </div>
        </div>
      </header>

      {/* ─────────────────────────────────────────
          HERO SECTION
      ───────────────────────────────────────── */}
      <section id="home" className="pt-16 sm:pt-24 pb-16 px-4 relative overflow-hidden">
        {/* Ambient neon backdrop glows */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-[#00ffaa]/10 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/3 left-1/4 w-[400px] h-[300px] bg-[#cc00ff]/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#00ffaa]/10 border border-[#00ffaa]/30 text-[#00ffaa] text-xs sm:text-sm font-semibold mb-6">
            <Sparkles className="w-4 h-4" />
            <span>AI QUANTUM PREDICTOR ENGINE v2026.4</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight leading-[1.08] mb-6">
            <span className="text-gradient-hero">97.8% WIN RATE</span>
            <br />
            <span className="text-white">STAKE.COM 2026</span>
          </h1>

          <p className="text-lg sm:text-2xl text-[#a0a0d0] font-normal max-w-2xl mx-auto mb-10 leading-relaxed">
            Used by <strong className="text-white font-bold">24,700+</strong> active players right now. Real-time safe
            tile mapping, crash multipliers, and probabilistic roll detection.
          </p>

          {/* Live Stat Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto mb-12">
            <div className="glass-panel p-5 rounded-2xl border border-[#1f2238] text-center">
              <div className="flex items-center justify-center gap-2 text-xs text-[#a0a0d0] uppercase font-semibold mb-1">
                <span className="w-2 h-2 rounded-full bg-[#00ffaa] animate-pulse" />
                Players Online
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#00ffaa]">
                {onlinePlayers.toLocaleString()}
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-[#1f2238] text-center">
              <div className="text-xs text-[#a0a0d0] uppercase font-semibold mb-1">
                Wins Today
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white">
                ${dailyWins.toLocaleString()}
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-[#1f2238] text-center">
              <div className="text-xs text-[#a0a0d0] uppercase font-semibold mb-1">
                Verified Accuracy
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#00ffaa]">
                97.8%
              </div>
            </div>

            <div className="glass-panel p-5 rounded-2xl border border-[#1f2238] text-center">
              <div className="text-xs text-[#a0a0d0] uppercase font-semibold mb-1">
                Avg Response Time
              </div>
              <div className="text-2xl sm:text-3xl font-black text-[#cc00ff]">
                12ms
              </div>
            </div>
          </div>

          {/* Hero CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => handleOpenPayment('7 Days', 145)}
              className="px-8 py-4 rounded-full font-bold text-base sm:text-lg bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all transform hover:-translate-y-1 glow-accent cursor-pointer shadow-xl flex items-center gap-2"
            >
              <Zap className="w-5 h-5 fill-current" />
              UNLOCK PREDICTOR (FROM $70)
            </button>
            <a
              href="#demo"
              className="px-8 py-4 rounded-full font-bold text-base sm:text-lg glass-panel hover:border-[#00ffaa]/50 text-white transition-all transform hover:-translate-y-1 cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-5 h-5 text-[#00ffaa]" />
              TRY LIVE DEMO
            </a>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────
          PRICING PLANS SECTION (FIRST MAIN)
      ───────────────────────────────────────── */}
      <section id="pricing" className="py-20 px-4 bg-[#0d0d1a]/60 relative">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-3">
              CHOOSE YOUR PLAN
            </h2>
            <p className="text-[#a0a0d0] text-base sm:text-lg max-w-xl mx-auto">
              Select your predictive telemetry duration. Instant activation across Windows PC and Android.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 px-5 py-2 rounded-full bg-[#ff3366]/15 border border-[#ff3366]/40 text-[#ff3366] font-bold text-sm sm:text-base animate-pulse">
              <Flame className="w-4 h-4" />
              Only <span className="font-extrabold underline">{vipSlots}</span> VIP activation slots remaining today!
            </div>
          </div>

          {/* 6 Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 items-stretch mb-12">
            {PRICING_PLANS.map((plan) => {
              const isPopular = plan.popular;
              const isGold = plan.highlight === 'gold';
              const isPurple = plan.highlight === 'purple';

              return (
                <div
                  key={plan.id}
                  className={`rounded-3xl p-7 flex flex-col justify-between transition-all relative ${
                    isPopular
                      ? 'glass-panel border-2 border-[#00ffaa] glow-accent md:-translate-y-2 bg-gradient-to-b from-[#141829] to-[#0f1122]'
                      : isGold
                      ? 'glass-panel-gold border-2 border-[#ffdd44] glow-gold md:-translate-y-1'
                      : isPurple
                      ? 'glass-panel border-2 border-[#cc00ff] glow-purple'
                      : 'glass-panel border border-[#22223a] hover:border-[#383858]'
                  }`}
                >
                  {/* Badge */}
                  <div className="flex justify-between items-start mb-4">
                    <span
                      className={`px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                        isPopular
                          ? 'bg-[#00ffaa] text-[#0b0b14] shadow'
                          : isGold
                          ? 'bg-gradient-to-r from-[#ffdd44] to-[#ffaa00] text-[#0b0b14] shadow'
                          : isPurple
                          ? 'bg-gradient-to-r from-[#cc00ff] to-[#ff3366] text-white shadow'
                          : 'bg-[#18182c] border border-[#2e2e48] text-[#00ffaa]'
                      }`}
                    >
                      {plan.badge}
                    </span>
                    <span className="text-xs font-mono text-[#a0a0d0] uppercase">{plan.duration}</span>
                  </div>

                  <div>
                    {/* Price */}
                    <div className="flex items-baseline gap-1 mb-2">
                      <span
                        className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${
                          isGold ? 'text-[#ffdd44]' : isPurple ? 'text-[#cc00ff]' : 'text-white'
                        }`}
                      >
                        ${plan.price.toLocaleString()}
                      </span>
                    </div>

                    <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                    <p className="text-xs text-[#a0a0d0] mb-6 leading-relaxed">{plan.description}</p>

                    {/* Features list */}
                    <ul className="space-y-3 mb-8 text-xs sm:text-sm text-[#e8e8ff]">
                      {plan.features.map((feat, idx) => (
                        <li key={idx} className="flex items-center gap-2.5">
                          <Check
                            className={`w-4 h-4 shrink-0 ${
                              isGold ? 'text-[#ffdd44]' : isPurple ? 'text-[#cc00ff]' : 'text-[#00ffaa]'
                            }`}
                          />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Purchase Button */}
                  <button
                    onClick={() => handleOpenPayment(plan.name, plan.price)}
                    className={`w-full py-3.5 rounded-full font-black text-sm transition-all transform hover:-translate-y-0.5 cursor-pointer shadow-lg flex items-center justify-center gap-2 ${
                      isPopular
                        ? 'bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 glow-accent'
                        : isGold
                        ? 'bg-gradient-to-r from-[#ffdd44] to-[#ffaa00] text-[#0b0b14] hover:opacity-95 glow-gold'
                        : isPurple
                        ? 'bg-gradient-to-r from-[#cc00ff] to-[#ff3366] text-white hover:opacity-95 glow-purple'
                        : 'bg-[#1a1a2e] border border-[#2e2e4a] text-white hover:border-[#00ffaa]/50 hover:bg-[#22223c]'
                    }`}
                  >
                    <Zap className="w-4 h-4 fill-current" />
                    UNLOCK {plan.name.toUpperCase()} (${plan.price.toLocaleString()})
                  </button>
                </div>
              );
            })}
          </div>

          {/* Free Evaluation Bar */}
          <div className="glass-panel p-6 sm:p-8 rounded-2xl border border-[#24243c] flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
            <div>
              <h4 className="text-lg font-bold text-white flex items-center justify-center sm:justify-start gap-2">
                <Download className="w-5 h-5 text-[#00ffaa]" />
                Looking for the Free Starter Trial?
              </h4>
              <p className="text-xs sm:text-sm text-[#a0a0d0] mt-1">
                Download the free evaluation build with low-confidence demo signals before selecting a pass.
              </p>
            </div>
            <a
              href={effectiveDownloadUrl}
              onClick={handleDownloadFree}
              className="px-6 py-3 rounded-full font-bold text-xs sm:text-sm bg-[#18182c] border border-[#30304c] text-white hover:bg-[#22223a] hover:border-[#00ffaa]/50 transition-all flex items-center gap-2 shrink-0 cursor-pointer"
            >
              {isDownloading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-[#00ffaa]" />
                  PREPARING...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  DOWNLOAD FREE STARTER
                </>
              )}
            </a>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────
          INTERACTIVE DEMO STUDIO (TRY THE BOT LIVE)
      ───────────────────────────────────────── */}
      <section id="demo" className="py-20 px-4 max-w-6xl mx-auto w-full">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00ffaa]/10 border border-[#00ffaa]/30 text-[#00ffaa] text-xs font-semibold uppercase mb-3">
            <Sliders className="w-3.5 h-3.5" />
            Interactive Sandbox
          </div>
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-2">
            TEST THE PREDICTION ENGINE
          </h2>
          <p className="text-[#a0a0d0] max-w-xl mx-auto text-sm sm:text-base">
            See how the AI algorithm calculates safe spots and exit points in real time before wagering.
          </p>
        </div>

        {/* Game switcher tabs */}
        <div className="flex justify-center mb-8">
          <div className="glass-panel p-1.5 rounded-full inline-flex border border-[#22223a]">
            <button
              onClick={() => setActiveDemoGame('mines')}
              className={`px-5 sm:px-8 py-2.5 rounded-full font-bold text-sm transition-all flex items-center gap-2 cursor-pointer ${
                activeDemoGame === 'mines'
                  ? 'bg-[#00ffaa] text-[#0b0b14] glow-accent'
                  : 'text-[#a0a0d0] hover:text-white'
              }`}
            >
              <Bomb className="w-4 h-4" />
              Mines Simulator
            </button>
            <button
              onClick={() => setActiveDemoGame('crash')}
              className={`px-5 sm:px-8 py-2.5 rounded-full font-bold text-sm transition-all flex items-center gap-2 cursor-pointer ${
                activeDemoGame === 'crash'
                  ? 'bg-[#cc00ff] text-white glow-purple'
                  : 'text-[#a0a0d0] hover:text-white'
              }`}
            >
              <Rocket className="w-4 h-4" />
              Crash Radar
            </button>
            <button
              onClick={() => setActiveDemoGame('dice')}
              className={`px-5 sm:px-8 py-2.5 rounded-full font-bold text-sm transition-all flex items-center gap-2 cursor-pointer ${
                activeDemoGame === 'dice'
                  ? 'bg-[#ffdd44] text-[#0b0b14] glow-gold'
                  : 'text-[#a0a0d0] hover:text-white'
              }`}
            >
              <Dices className="w-4 h-4" />
              Dice Probability
            </button>
          </div>
        </div>

        {/* Game Canvas / Interface Container */}
        <div className="glass-panel rounded-3xl p-6 sm:p-10 border border-[#22223a] relative overflow-hidden">
          {/* MINES ENGINE */}
          {activeDemoGame === 'mines' && (
            <div className="max-w-2xl mx-auto">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div>
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    <Bomb className="w-5 h-5 text-[#00ffaa]" />
                    Stake 5x5 Mines Grid
                  </h3>
                  <p className="text-xs text-[#a0a0d0]">
                    AI scans pseudo-random seeds and flags 5 predicted safe diamond tiles with 97.8% certainty.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-xs text-[#a0a0d0]">
                    Mines:
                    <select
                      value={mineCount}
                      onChange={(e) => setMineCount(Number(e.target.value))}
                      className="ml-2 bg-[#18182a] border border-[#30304a] text-[#00ffaa] font-bold rounded-lg px-2 py-1 outline-none"
                    >
                      <option value="1">1 Mine</option>
                      <option value="3">3 Mines (Standard)</option>
                      <option value="5">5 Mines</option>
                      <option value="10">10 Mines</option>
                    </select>
                  </div>

                  <button
                    onClick={scanMines}
                    disabled={isScanning}
                    className="px-4 py-2 rounded-xl font-bold text-xs sm:text-sm bg-[#00ffaa] text-[#0b0b14] hover:bg-[#00dd90] transition-all flex items-center gap-1.5 cursor-pointer glow-accent disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                    {isScanning ? 'SCANNING SEED...' : 'GENERATE SAFE TILES'}
                  </button>
                </div>
              </div>

              {/* 5x5 Grid */}
              <div className="grid grid-cols-5 gap-2.5 sm:gap-3 max-w-md mx-auto aspect-square p-3 sm:p-4 rounded-2xl bg-[#0e0e1a] border border-[#222238] relative">
                {Array.from({ length: 25 }, (_, i) => {
                  const tileId = i + 1;
                  const isPredicted = predictedTiles.includes(tileId);
                  const state = revealedTiles[tileId];

                  return (
                    <button
                      key={tileId}
                      onClick={() => clickTile(tileId)}
                      className={`relative rounded-xl font-bold transition-all flex items-center justify-center cursor-pointer text-sm sm:text-base border ${
                        state === 'diamond'
                          ? 'bg-[#00ffaa]/20 border-[#00ffaa] text-[#00ffaa] shadow-[0_0_15px_rgba(0,255,170,0.5)]'
                          : state === 'mine'
                          ? 'bg-[#ff3366]/20 border-[#ff3366] text-[#ff3366]'
                          : isPredicted
                          ? 'bg-[#152822] border-[#00ffaa]/60 text-[#00ffaa] hover:bg-[#1a382e] shadow-[0_0_10px_rgba(0,255,170,0.2)]'
                          : 'bg-[#18182c] border-[#252540] text-[#a0a0d0] hover:bg-[#20203a]'
                      }`}
                    >
                      {state === 'diamond' && '💎'}
                      {state === 'mine' && '💣'}
                      {!state && (
                        <>
                          <span className="opacity-40 text-xs font-mono">{tileId}</span>
                          {isPredicted && (
                            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#00ffaa] animate-ping" />
                          )}
                        </>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Predicted Tiles Readout */}
              <div className="mt-6 p-4 rounded-xl bg-[#00ffaa]/10 border border-[#00ffaa]/30 flex flex-wrap items-center justify-between gap-3 text-sm">
                <div>
                  <span className="text-white font-bold">Predicted Safe Tiles: </span>
                  <span className="text-[#00ffaa] font-mono font-bold tracking-wider">
                    {predictedTiles.sort((a, b) => a - b).join(', ')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#a0a0d0]">Accuracy Confidence:</span>
                  <span className="px-2 py-0.5 rounded bg-[#00ffaa]/20 text-[#00ffaa] font-black text-xs">
                    97.8%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* CRASH ENGINE */}
          {activeDemoGame === 'crash' && (
            <div className="max-w-xl mx-auto text-center">
              <h3 className="text-xl font-bold text-white mb-2 flex items-center justify-center gap-2">
                <Rocket className="w-5 h-5 text-[#cc00ff]" />
                Crash Multiplier Trajectory Radar
              </h3>
              <p className="text-xs text-[#a0a0d0] mb-6">
                Calculates the exact sub-second cash-out multiplier prior to server bust.
              </p>

              {/* Multiplier Display Screen */}
              <div className="p-10 rounded-2xl bg-[#0d0d1a] border border-[#2a2a44] mb-6 relative overflow-hidden flex flex-col items-center justify-center min-h-[220px]">
                <div className="text-5xl sm:text-7xl font-black font-mono tracking-tight transition-all duration-75">
                  <span
                    className={
                      crashState === 'crashed'
                        ? 'text-[#ff3366]'
                        : crashState === 'cashed'
                        ? 'text-[#00ffaa]'
                        : 'text-white'
                    }
                  >
                    {crashMultiplier.toFixed(2)}x
                  </span>
                </div>

                <div className="mt-3 text-sm font-semibold">
                  {crashState === 'idle' && (
                    <span className="text-[#a0a0d0]">Press "Run Round" to simulate live trajectory</span>
                  )}
                  {crashState === 'running' && (
                    <span className="text-[#cc00ff] animate-pulse">Scanning server hashes...</span>
                  )}
                  {crashState === 'cashed' && (
                    <span className="text-[#00ffaa]">✅ CASHED OUT AT {crashTarget}x! Win Locked!</span>
                  )}
                  {crashState === 'crashed' && (
                    <span className="text-[#ff3366]">💥 CRASHED! (Safe cashout was {crashTarget}x)</span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6 text-left">
                <div className="p-4 rounded-xl bg-[#141424] border border-[#24243a]">
                  <span className="text-xs text-[#a0a0d0] block">AI Suggested Cash-Out</span>
                  <span className="text-2xl font-bold text-[#cc00ff]">{crashTarget}x</span>
                </div>
                <div className="p-4 rounded-xl bg-[#141424] border border-[#24243a]">
                  <span className="text-xs text-[#a0a0d0] block">Confidence Level</span>
                  <span className="text-2xl font-bold text-[#00ffaa]">94.2%</span>
                </div>
              </div>

              <button
                onClick={runCrashSimulation}
                disabled={isCrashRunning}
                className="px-8 py-3.5 rounded-full font-bold text-sm bg-gradient-to-r from-[#cc00ff] to-[#9900cc] text-white hover:opacity-90 transition-all glow-purple cursor-pointer disabled:opacity-50"
              >
                {isCrashRunning ? 'SIMULATING ROCKET...' : 'SIMULATE CRASH ROUND'}
              </button>
            </div>
          )}

          {/* DICE ENGINE */}
          {activeDemoGame === 'dice' && (
            <div className="max-w-xl mx-auto text-center">
              <h3 className="text-xl font-bold text-white mb-2 flex items-center justify-center gap-2">
                <Dices className="w-5 h-5 text-[#ffdd44]" />
                Dice Probability Boundaries
              </h3>
              <p className="text-xs text-[#a0a0d0] mb-6">
                Calculates dynamic Roll Over/Under thresholds for steady compounding runs.
              </p>

              <div className="p-8 rounded-2xl bg-[#0d0d1a] border border-[#2a2a44] mb-6">
                <div className="flex justify-between items-center text-sm font-semibold mb-3">
                  <span className="text-[#a0a0d0]">Roll Condition</span>
                  <span className="text-[#ffdd44] font-mono text-lg font-bold">
                    Roll Over {diceRollOver}
                  </span>
                </div>

                <input
                  type="range"
                  min="2"
                  max="98"
                  step="0.01"
                  value={diceRollOver}
                  onChange={(e) => setDiceRollOver(Number(e.target.value))}
                  className="w-full h-3 bg-[#1e1e32] rounded-lg appearance-none cursor-pointer accent-[#ffdd44] mb-6"
                />

                <div className="grid grid-cols-2 gap-4 text-left">
                  <div className="p-3 rounded-lg bg-[#141424]">
                    <span className="text-xs text-[#a0a0d0]">Win Chance</span>
                    <p className="text-lg font-bold text-white">{(100 - diceRollOver).toFixed(2)}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-[#141424]">
                    <span className="text-xs text-[#a0a0d0]">AI Recommended Over</span>
                    <p className="text-lg font-bold text-[#ffdd44]">33.33 (96.5% Conf.)</p>
                  </div>
                </div>

                {lastDiceResult !== null && (
                  <div className="mt-6 pt-4 border-t border-[#22223a]">
                    <span className="text-xs text-[#a0a0d0]">Result: </span>
                    <span
                      className={`text-2xl font-mono font-black ${
                        lastDiceResult > diceRollOver ? 'text-[#00ffaa]' : 'text-[#ff3366]'
                      }`}
                    >
                      {lastDiceResult} {lastDiceResult > diceRollOver ? '🎯 WIN' : '❌ MISS'}
                    </span>
                  </div>
                )}
              </div>

              <button
                onClick={rollDiceSimulation}
                className="px-8 py-3.5 rounded-full font-bold text-sm bg-gradient-to-r from-[#ffdd44] to-[#ffaa00] text-[#0b0b14] hover:opacity-90 transition-all glow-gold cursor-pointer"
              >
                ROLL SIMULATION
              </button>
            </div>
          )}
        </div>
      </section>

      {/* ─────────────────────────────────────────
          LIVE SIGNALS FEED
      ───────────────────────────────────────── */}
      <section id="signals" className="py-20 px-4 bg-[#0d0d1a]/60">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-2 text-[#00ffaa]">
              📊 LIVE SIGNALS
            </h2>
            <p className="text-[#a0a0d0] text-sm sm:text-base">
              Real-time algorithm telemetry broadcast directly to subscribers.
            </p>
          </div>

          <div className="glass-panel rounded-3xl p-6 sm:p-10 border border-[#22223a]">
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-[#22223a]">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ff3366] animate-ping" />
                <span className="font-bold text-white uppercase tracking-wider text-sm">
                  LIVE NOW - Real-time Predictions
                </span>
              </div>
              <span className="text-xs text-[#a0a0d0] font-mono">Updated just now</span>
            </div>

            <div className="space-y-4 mb-8">
              {/* Mines Card */}
              <div className="p-5 rounded-2xl bg-[#00ffaa]/10 border border-[#00ffaa]/30 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#00ffaa]/20 flex items-center justify-center text-2xl">
                    💣
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base sm:text-lg text-white">MINES</h4>
                    <p className="text-xs sm:text-sm text-[#a0a0d0]">
                      Safe Tiles: <strong className="text-[#00ffaa]">3, 7, 12, 18, 22</strong>
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xl sm:text-2xl font-black text-[#00ffaa]">97.8%</span>
                  <p className="text-[11px] text-[#a0a0d0] uppercase">Confidence</p>
                </div>
              </div>

              {/* Crash Card */}
              <div className="p-5 rounded-2xl bg-[#cc00ff]/10 border border-[#cc00ff]/30 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#cc00ff]/20 flex items-center justify-center text-2xl">
                    🚀
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base sm:text-lg text-white">CRASH</h4>
                    <p className="text-xs sm:text-sm text-[#a0a0d0]">
                      Cash out at: <strong className="text-[#cc00ff]">2.34x</strong>
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xl sm:text-2xl font-black text-[#cc00ff]">94.2%</span>
                  <p className="text-[11px] text-[#a0a0d0] uppercase">Confidence</p>
                </div>
              </div>

              {/* Dice Card */}
              <div className="p-5 rounded-2xl bg-[#ffdd44]/10 border border-[#ffdd44]/30 flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#ffdd44]/20 flex items-center justify-center text-2xl">
                    🎲
                  </div>
                  <div>
                    <h4 className="font-extrabold text-base sm:text-lg text-white">DICE</h4>
                    <p className="text-xs sm:text-sm text-[#a0a0d0]">
                      Roll Over: <strong className="text-[#ffdd44]">33.33</strong>
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xl sm:text-2xl font-black text-[#ffdd44]">96.5%</span>
                  <p className="text-[11px] text-[#a0a0d0] uppercase">Confidence</p>
                </div>
              </div>
            </div>

            {/* Locked Premium CTA */}
            <div className="p-6 rounded-2xl bg-[#ff3366]/10 border border-[#ff3366]/30 text-center">
              <div className="w-10 h-10 rounded-full bg-[#ff3366]/20 flex items-center justify-center mx-auto mb-3 text-[#ff3366]">
                <Lock className="w-5 h-5" />
              </div>
              <h4 className="font-black text-lg text-white mb-1">🔒 Premium signals are locked</h4>
              <p className="text-sm text-[#a0a0d0] mb-5 max-w-md mx-auto">
                Unlock full access to receive real-time automated signals for Limbo, Plinko, Dragon Tower & Keno.
              </p>
              <button
                onClick={() => handleOpenPayment('7 Days', 145)}
                className="px-8 py-3.5 rounded-full font-bold text-sm bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all glow-accent cursor-pointer"
              >
                🔓 UNLOCK PREMIUM SIGNALS
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────
          PROOF & RECENT BIG WINS
      ───────────────────────────────────────── */}
      <section id="proof" className="py-20 px-4 max-w-6xl mx-auto w-full">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-5xl font-black tracking-tight mb-2 text-[#00ffaa]">
            🏆 PROOF & RESULTS
          </h2>
          <p className="text-[#a0a0d0] text-sm sm:text-base">
            Verified payouts documented across verified crypto blockchain transactions.
          </p>
        </div>

        {/* Global Numbers */}
        <div className="glass-panel p-8 rounded-3xl border border-[#22223a] mb-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl sm:text-5xl font-black text-[#00ffaa] mb-1">$2.4M+</div>
              <div className="text-xs sm:text-sm text-[#a0a0d0]">Total Winnings</div>
            </div>
            <div>
              <div className="text-3xl sm:text-5xl font-black text-white mb-1">24,700+</div>
              <div className="text-xs sm:text-sm text-[#a0a0d0]">Active Users</div>
            </div>
            <div>
              <div className="text-3xl sm:text-5xl font-black text-[#00ffaa] mb-1">97.8%</div>
              <div className="text-xs sm:text-sm text-[#a0a0d0]">Win Rate</div>
            </div>
            <div>
              <div className="text-3xl sm:text-5xl font-black text-[#ffdd44] mb-1">4.9 ⭐</div>
              <div className="text-xs sm:text-sm text-[#a0a0d0]">User Rating</div>
            </div>
          </div>
        </div>

        {/* Recent Big Wins Feed */}
        <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-[#22223a]">
          <h3 className="text-xl font-bold text-[#00ffaa] mb-6 flex items-center gap-2">
            <span>💰</span> Recent Big Wins
          </h3>

          <div className="space-y-3">
            {[
              { handle: '@CryptoKing', game: 'Mines', time: '5 minutes ago', amount: '+$4,250', icon: '🎰' },
              { handle: '@DiamondHands', game: 'Crash', time: '12 minutes ago', amount: '+$2,890', icon: '🚀' },
              { handle: '@LuckyAce', game: 'Dice', time: '18 minutes ago', amount: '+$1,670', icon: '🎲' },
              { handle: '@HighRoller99', game: 'Mines', time: '25 minutes ago', amount: '+$6,120', icon: '💎' },
              { handle: '@MoonShot', game: 'Crash', time: '32 minutes ago', amount: '+$3,450', icon: '🔥' },
            ].map((win, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-[#00ffaa]/5 border border-[#00ffaa]/15 flex items-center justify-between gap-4 hover:bg-[#00ffaa]/10 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{win.icon}</span>
                  <div>
                    <strong className="text-white font-bold text-sm sm:text-base">{win.handle}</strong>
                    <p className="text-xs text-[#a0a0d0]">
                      {win.game} • {win.time}
                    </p>
                  </div>
                </div>
                <span className="text-lg sm:text-xl font-black text-[#00ffaa] font-mono">
                  {win.amount}
                </span>
              </div>
            ))}
          </div>

          <div className="text-center mt-8">
            <button
              onClick={() => handleOpenPayment('7 Days', 145)}
              className="px-8 py-3.5 rounded-full font-bold text-sm bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all glow-accent cursor-pointer"
            >
              🚀 START WINNING NOW
            </button>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────
          VIP ACCESS SECTION
      ───────────────────────────────────────── */}
      <section id="vip" className="py-20 px-4 bg-gradient-to-b from-[#14120a] to-[#0b0b14] border-t border-[#2a2410]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-1 text-3xl mb-2">👑</div>
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-[#ffdd44] mb-3">
              VIP ACCESS
            </h2>
            <p className="text-[#a0a0d0] text-base sm:text-lg max-w-xl mx-auto">
              Exclusive privileges crafted specifically for serious high-roller profit runs.
            </p>
          </div>

          {/* 6 VIP Pillars */}
          <div className="glass-panel-gold rounded-3xl p-8 border border-[#ffdd44]/30 mb-10">
            <h3 className="text-xl font-bold text-[#ffdd44] text-center mb-8">
              🌟 VIP Exclusive Benefits
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {[
                {
                  icon: '🎯',
                  title: '99.2% Accuracy',
                  desc: 'Higher confidence algorithm calibrated for high wager safety.',
                },
                {
                  icon: '⚡',
                  title: 'Instant Signals',
                  desc: 'Zero-delay socket feed ahead of standard server rounds.',
                },
                {
                  icon: '🔮',
                  title: 'All Games Unlocked',
                  desc: 'Mines, Crash, Dice, Plinko, Limbo, Keno, Roulette, Baccarat.',
                },
                {
                  icon: '💬',
                  title: 'Private VIP Discord',
                  desc: 'Private high-stakes community and strategy masterclasses.',
                },
                {
                  icon: '🔄',
                  title: 'Free Updates',
                  desc: 'All 2026 and future engine updates pushed automatically.',
                },
                {
                  icon: '🛡️',
                  title: 'Priority Support',
                  desc: '1-on-1 dedicated engineer assistance available 24/7.',
                },
              ].map((card, i) => (
                <div
                  key={i}
                  className="p-6 rounded-2xl bg-[#ffdd44]/10 border border-[#ffdd44]/20 text-center"
                >
                  <span className="text-3xl block mb-3">{card.icon}</span>
                  <h4 className="font-bold text-[#ffdd44] text-lg mb-1">{card.title}</h4>
                  <p className="text-xs text-[#a0a0d0] leading-relaxed">{card.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Lifetime VIP & Source Code Big Boxes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Infinite Pass ($2,000) */}
            <div className="glass-panel-gold rounded-3xl p-8 border-2 border-[#ffdd44] text-center glow-gold flex flex-col justify-between">
              <div>
                <span className="text-5xl block mb-3">👑</span>
                <span className="px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-[#ffdd44] to-[#ffaa00] text-[#0b0b14] inline-block mb-3">
                  LIFETIME VIP
                </span>
                <h3 className="text-2xl font-black text-white mb-2">Infinite Pass</h3>
                <p className="text-xs text-[#a0a0d0] mb-5 leading-relaxed">
                  Never pay a monthly subscription again. One single crypto transfer guarantees permanent lifetime activation & updates.
                </p>

                <div className="text-4xl sm:text-5xl font-black text-[#ffdd44] font-mono mb-2">
                  $2,000
                </div>
                <p className="text-[11px] text-[#ffdd44] font-semibold mb-6">
                  ✅ Lifetime updates • ✅ VIP Lounge • ✅ 99.2% Accuracy
                </p>
              </div>

              <button
                onClick={() => handleOpenPayment('Infinite Pass', 2000)}
                className="w-full py-4 rounded-full font-black text-sm sm:text-base bg-gradient-to-r from-[#ffdd44] to-[#ffaa00] text-[#0b0b14] hover:opacity-95 transition-all transform hover:-translate-y-1 glow-gold cursor-pointer shadow-xl flex items-center justify-center gap-2"
              >
                <Crown className="w-5 h-5 fill-current" />
                GET INFINITE PASS ($2,000)
              </button>
            </div>

            {/* Source Code ($10,000) */}
            <div className="glass-panel rounded-3xl p-8 border-2 border-[#cc00ff] text-center glow-purple flex flex-col justify-between bg-gradient-to-b from-[#181026] to-[#0f0b18]">
              <div>
                <span className="text-5xl block mb-3">⚡</span>
                <span className="px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-[#cc00ff] to-[#ff3366] text-white inline-block mb-3">
                  COMMERCIAL OWNERSHIP
                </span>
                <h3 className="text-2xl font-black text-white mb-2">Full Source Code</h3>
                <p className="text-xs text-[#a0a0d0] mb-5 leading-relaxed">
                  Get the complete uncompiled algorithmic codebase, AI machine learning weights, and 100% white-label commercial rights.
                </p>

                <div className="text-4xl sm:text-5xl font-black text-[#cc00ff] font-mono mb-2">
                  $10,000
                </div>
                <p className="text-[11px] text-[#cc00ff] font-semibold mb-6">
                  ✅ Uncompiled code • ✅ Commercial rights • ✅ Dev setup call
                </p>
              </div>

              <button
                onClick={() => handleOpenPayment('Source Code', 10000)}
                className="w-full py-4 rounded-full font-black text-sm sm:text-base bg-gradient-to-r from-[#cc00ff] to-[#ff3366] text-white hover:opacity-95 transition-all transform hover:-translate-y-1 glow-purple cursor-pointer shadow-xl flex items-center justify-center gap-2"
              >
                <Zap className="w-5 h-5 fill-current" />
                BUY SOURCE CODE ($10,000)
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ─────────────────────────────────────────
          PAYMENT POPUP MODAL
      ───────────────────────────────────────── */}
      {isPaymentOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-start justify-center p-4 overflow-y-auto">
          <div className="my-8 max-w-md w-full rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-[#16162a] via-[#121224] to-[#0c0c18] border-2 border-[#00ffaa] shadow-2xl relative glow-accent">
            {/* Close Button */}
            <button
              onClick={() => setIsPaymentOpen(false)}
              className="absolute top-5 right-5 text-[#a0a0d0] hover:text-[#ff3366] transition-colors p-1"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Modal Title */}
            <div className="text-center mb-5">
              <h3 className="text-xl sm:text-2xl font-black text-[#00ffaa] flex items-center justify-center gap-2 mb-1">
                <Crown className="w-5 h-5 text-[#ffdd44]" />
                Complete Your Purchase
              </h3>
              <div className="text-sm text-[#a0a0d0] flex items-center justify-center gap-2">
                <span className="font-bold text-white">{selectedPlan}</span>
                <span>•</span>
                <strong className="text-2xl font-black text-[#ffdd44] font-mono">
                  ${selectedPrice.toLocaleString()}
                </strong>
              </div>
            </div>

            {/* 6 Plan Switcher Buttons */}
            <label className="text-[11px] text-[#a0a0d0] uppercase font-bold tracking-wider block mb-2 text-center">
              Choose Plan Duration:
            </label>
            <div className="grid grid-cols-3 gap-1.5 p-1.5 bg-[#0b0b14] rounded-2xl mb-5 text-[11px] font-bold">
              {PRICING_PLANS.map((plan) => (
                <button
                  key={plan.id}
                  onClick={() => {
                    setSelectedPlan(plan.name);
                    setSelectedPrice(plan.price);
                  }}
                  className={`py-2 px-1 rounded-xl transition-all cursor-pointer flex flex-col items-center justify-center text-center leading-tight ${
                    selectedPlan === plan.name
                      ? plan.highlight === 'gold'
                        ? 'bg-[#ffdd44] text-[#0b0b14] shadow'
                        : plan.highlight === 'purple'
                        ? 'bg-[#cc00ff] text-white shadow'
                        : 'bg-[#00ffaa] text-[#0b0b14] shadow'
                      : 'text-[#a0a0d0] hover:text-white bg-[#141424] hover:bg-[#1a1a2e]'
                  }`}
                >
                  <span className="font-black truncate w-full">{plan.name}</span>
                  <span className="text-[10px] opacity-90 font-mono">${plan.price.toLocaleString()}</span>
                </button>
              ))}
            </div>

            {/* Crypto Selection Buttons */}
            <label className="text-xs text-[#a0a0d0] uppercase font-bold tracking-wider block mb-2">
              Select Payment Crypto:
            </label>
            <div className="grid grid-cols-2 gap-2 mb-5">
              {Object.entries(CRYPTO_CONFIG).map(([key, item]) => (
                <button
                  key={key}
                  onClick={() => setSelectedCrypto(key)}
                  className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2.5 transition-all cursor-pointer ${
                    selectedCrypto === key
                      ? 'border-[#00ffaa] bg-[#00ffaa]/15 text-white'
                      : 'border-[#26263e] bg-[#141424] text-[#a0a0d0] hover:border-[#383856]'
                  }`}
                >
                  <span className={`w-3.5 h-3.5 rounded-full ${item.iconBg} shrink-0`} />
                  <span className="truncate">{item.name}</span>
                </button>
              ))}
            </div>

            {/* Wallet Address & Amount Box */}
            <div className="p-4 rounded-2xl bg-[#090912] border border-[#232338] mb-5">
              <div className="text-xs text-[#a0a0d0] mb-1">Send exact calculated crypto amount:</div>
              <div className="text-2xl font-black text-[#ffdd44] font-mono tracking-tight my-1">
                {isPriceLoading ? (
                  <span className="text-sm text-[#a0a0d0]">Loading live rate...</span>
                ) : (
                  `${exactCryptoAmount} ${CRYPTO_CONFIG[selectedCrypto]?.symbol}`
                )}
              </div>
              <div className="text-[11px] text-[#a0a0d0] mb-3">
                Network: <span className="text-white font-semibold">{CRYPTO_CONFIG[selectedCrypto]?.network}</span>
              </div>

              {/* Address with Copy */}
              <div className="relative p-3 rounded-xl bg-[#030308] border border-[#202033] font-mono text-xs text-[#00ffaa] break-all pr-20 select-all">
                {CRYPTO_CONFIG[selectedCrypto]?.address}
                <button
                  onClick={() => handleCopy(CRYPTO_CONFIG[selectedCrypto]?.address)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg bg-[#00ffaa] text-[#0b0b14] font-bold text-xs hover:bg-[#00dd90] transition-colors cursor-pointer flex items-center gap-1 shadow"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'COPIED!' : 'COPY'}
                </button>
              </div>
            </div>

            {/* Countdown Urgency */}
            <div className="text-center mb-5">
              <div className="text-xs text-[#a0a0d0] mb-0.5">⏱️ Time window to lock this exchange rate:</div>
              <div
                className={`text-2xl font-black font-mono tracking-wider ${
                  paymentTimer <= 120 ? 'text-[#ff3366] animate-pulse' : 'text-[#ff3366]'
                }`}
              >
                {formatTimer(paymentTimer)}
              </div>
            </div>

            {/* Status Feedback Area */}
            {paymentStatus === 'initial' && (
              <div className="p-3 rounded-xl bg-[#ffdd44]/10 border border-[#ffdd44]/30 text-center text-xs text-[#ffdd44] mb-4">
                ⏳ Send the crypto to the address above, then click the confirmation button below.
              </div>
            )}

            {paymentStatus === 'waiting' && (
              <div className="p-4 rounded-xl bg-[#00ffaa]/10 border border-[#00ffaa]/30 text-center mb-4">
                <div className="text-xs font-semibold text-white mb-1">
                  ✅ Payment request registered!
                </div>
                <div className="text-sm font-mono font-bold text-[#00ffaa] bg-black/40 p-2 rounded-lg my-1">
                  ID: {paymentId}
                </div>
                <p className="text-xs text-[#a0a0d0]">
                  Awaiting blockchain confirmation & admin webhook approval...
                </p>
                <div className="flex items-center justify-center gap-2 mt-2 text-xs text-[#ffdd44]">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Polling server status...</span>
                </div>
              </div>
            )}

            {paymentStatus === 'approved' && (
              <div className="p-4 rounded-xl bg-[#00ffaa]/20 border border-[#00ffaa] text-center text-[#00ffaa] font-bold text-sm mb-4">
                🎉 Payment APPROVED! Opening your download...
              </div>
            )}

            {paymentStatus === 'rejected' && (
              <div className="p-4 rounded-xl bg-[#ff3366]/20 border border-[#ff3366] text-center text-[#ff3366] text-xs mb-4">
                ❌ Payment not verified or rejected. Please check your transaction hash or contact support.
              </div>
            )}

            {/* Action Button */}
            <button
              onClick={handleConfirmPayment}
              disabled={isSendingRequest || paymentStatus === 'approved'}
              className="w-full py-4 rounded-xl font-black text-sm sm:text-base bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all glow-accent cursor-pointer disabled:opacity-50 shadow-lg"
            >
              {isSendingRequest
                ? 'TRANSMITTING REQUEST...'
                : paymentStatus === 'waiting'
                ? 'REFRESH / CHECK APPROVAL'
                : 'I HAVE SENT THE PAYMENT'}
            </button>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────
          SUCCESS POPUP MODAL
      ───────────────────────────────────────── */}
      {isSuccessOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-lg w-full rounded-3xl p-8 sm:p-10 bg-gradient-to-br from-[#0c1c14] to-[#08140e] border-3 border-[#00ffaa] text-center shadow-2xl relative glow-accent-lg">
            <button
              onClick={() => setIsSuccessOpen(false)}
              className="absolute top-5 right-5 text-[#a0a0d0] hover:text-white"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="w-20 h-20 rounded-full bg-[#00ffaa]/20 border-2 border-[#00ffaa] flex items-center justify-center mx-auto mb-6 text-4xl glow-accent">
              ✅
            </div>

            <h3 className="text-3xl font-black text-[#00ffaa] mb-2">Payment Confirmed!</h3>
            <p className="text-sm text-[#a0a0d0] mb-6 leading-relaxed">
              Thank you for your purchase! Your VIP access has been activated across all servers.
            </p>

            {/* Generated License Key */}
            <div className="p-4 rounded-2xl bg-black/60 border border-[#00ffaa]/30 mb-8">
              <span className="text-xs text-[#a0a0d0] block mb-1">Your Software VIP Activation Key:</span>
              <div className="flex items-center justify-center gap-2">
                <span className="font-mono text-lg font-black text-[#ffdd44] tracking-wider">
                  {licenseKey}
                </span>
                <button
                  onClick={() => handleCopy(licenseKey)}
                  className="p-1.5 rounded-lg bg-[#00ffaa]/20 text-[#00ffaa] hover:bg-[#00ffaa]/30 cursor-pointer"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            <a
              href={effectiveDownloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-10 py-4 rounded-full font-black text-lg bg-gradient-to-r from-[#00ffaa] to-[#00cc99] text-[#0b0b14] hover:opacity-95 transition-all glow-accent cursor-pointer shadow-xl mb-3"
            >
              <Download className="w-5 h-5" />
              📥 DOWNLOAD NOW
            </a>

            <p className="text-xs text-[#a0a0d0]">
              Compatible with Windows 10/11 (64-bit) & Android APK (Android 9.0+)
            </p>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────
          FLOATING TOAST NOTIFICATION
      ───────────────────────────────────────── */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-6 py-3.5 rounded-full bg-[#141424]/90 border border-[#00ffaa] text-white text-xs sm:text-sm font-semibold shadow-2xl backdrop-blur-xl flex items-center gap-3 animate-bounce glow-accent">
          <span className="w-2.5 h-2.5 rounded-full bg-[#00ffaa]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ─────────────────────────────────────────
          HIDDEN SEO SECTION (CRITICAL FOR RANKING)
      ───────────────────────────────────────── */}
      <section
        className="sr-only"
        aria-hidden="false"
      >
        <h1>Stake Bot Predictor 2026 - Best AI Prediction Tool for Stake.com</h1>
        <article>
          <h2>What is Stake Bot Predictor?</h2>
          <p>
            Stake Bot Predictor is the most advanced AI-powered prediction software for Stake.com casino games in 2026.
            Our cutting-edge algorithm analyzes patterns and provides accurate predictions for Mines, Crash, Dice,
            Plinko, and other popular games with 97.8% win rate.
          </p>
        </article>
        <article>
          <h2>Stake Mines Predictor</h2>
          <p>
            Our Stake Mines predictor uses advanced pattern recognition to identify safe tiles with incredible accuracy.
            Keywords: stake mines hack, stake mines predictor, stake mines bot, mines safe spots predictor.
          </p>
        </article>
        <article>
          <h2>Stake Crash Predictor</h2>
          <p>
            The Stake Crash predictor analyzes historical crash data to predict optimal cash-out multipliers with 94.2% accuracy.
            Keywords: stake crash predictor, crash gambling bot, crash prediction algorithm.
          </p>
        </article>
      </section>

      {/* ─────────────────────────────────────────
          FOOTER
      ───────────────────────────────────────── */}
      <footer className="py-12 border-t border-[#141422] text-center text-xs text-[#626284] px-4">
        <div className="max-w-4xl mx-auto space-y-4">
          <p className="max-w-xl mx-auto text-[#72729a] leading-relaxed">
            Disclaimer: Gambling involves financial risk. No profit is 100% guaranteed. Play responsibly.
            This prediction tool is provided for educational and analytical purposes.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs text-[#8c8cb8]">
            <a href="#home" className="hover:text-[#00ffaa]">Home</a>
            <a href="#signals" className="hover:text-[#00ffaa]">Live Signals</a>
            <a href="#proof" className="hover:text-[#00ffaa]">Proof & Results</a>
            <a href="#vip" className="hover:text-[#ffdd44]">VIP Membership</a>
            <a href={effectiveDownloadUrl} target="_blank" rel="noreferrer" className="hover:text-[#00ffaa]">Free Download</a>
          </div>
          <p>© 2026 Stake Bot Predictor. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
